<?php
include 'conexao.php';

$dados = json_decode(file_get_contents("php://input"));
$acao = isset($dados->acao) ? $dados->acao : (isset($_GET['acao']) ? $_GET['acao'] : '');

if ($acao === 'solicitar' && isset($dados->solicitante_id) && isset($dados->destinatario_id)) {
    $solicitante_id = (int)$dados->solicitante_id;
    $destinatario_id = (int)$dados->destinatario_id;

    if ($solicitante_id == $destinatario_id) {
        echo json_encode(["sucesso" => false, "mensagem" => "Você não pode adicionar a si mesmo."]);
        $conn->close();
        exit();
    }

    $check = $conn->query("SELECT id, status FROM amizades
                           WHERE (solicitante_id = $solicitante_id AND destinatario_id = $destinatario_id)
                              OR (solicitante_id = $destinatario_id AND destinatario_id = $solicitante_id)
                           LIMIT 1");

    if ($check && $check->num_rows > 0) {
        echo json_encode(["sucesso" => false, "mensagem" => "Já existe uma solicitação ou amizade com este usuário."]);
    } else {
        $sql = "INSERT INTO amizades (solicitante_id, destinatario_id, status) VALUES ($solicitante_id, $destinatario_id, 'pendente')";
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["sucesso" => true, "mensagem" => "Solicitação de amizade enviada!"]);
        } else {
            echo json_encode(["sucesso" => false, "mensagem" => "Erro ao solicitar amizade."]);
        }
    }
} elseif ($acao === 'aceitar') {
    if (isset($dados->amizade_id) && (int)$dados->amizade_id > 0) {
        $amizade_id = (int)$dados->amizade_id;
        $sql = "UPDATE amizades SET status = 'aceita' WHERE id = $amizade_id";
    } elseif (isset($dados->solicitante_id) && isset($dados->destinatario_id)) {
        $solicitante_id = (int)$dados->solicitante_id;
        $destinatario_id = (int)$dados->destinatario_id;
        $sql = "UPDATE amizades SET status = 'aceita'
                WHERE (solicitante_id = $solicitante_id AND destinatario_id = $destinatario_id)
                   OR (solicitante_id = $destinatario_id AND destinatario_id = $solicitante_id)";
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Dados incompletos para aceitar amizade."]);
        $conn->close();
        exit();
    }

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["sucesso" => true, "mensagem" => "Amizade aprovada com sucesso!"]);
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Erro ao aprovar amizade."]);
    }
} elseif ($acao === 'listar_pendentes') {
    $usuario_id = isset($_GET['usuario_id']) ? (int)$_GET['usuario_id'] : (isset($dados->usuario_id) ? (int)$dados->usuario_id : 0);

    $sql = "SELECT a.id AS amizade_id, a.solicitante_id, u.nome AS solicitante_nome, u.email AS solicitante_email
            FROM amizades a
            INNER JOIN usuarios u ON a.solicitante_id = u.id
            WHERE a.destinatario_id = $usuario_id AND a.status = 'pendente'
            ORDER BY a.id DESC";

    $res = $conn->query($sql);
    $solicitacoes = [];
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $solicitacoes[] = [
                "amizade_id" => (int)$row['amizade_id'],
                "solicitante_id" => (int)$row['solicitante_id'],
                "solicitante_nome" => $row['solicitante_nome'],
                "solicitante_email" => $row['solicitante_email']
            ];
        }
    }
    echo json_encode(["sucesso" => true, "solicitacoes" => $solicitacoes]);
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Ação inválida."]);
}

$conn->close();
?>