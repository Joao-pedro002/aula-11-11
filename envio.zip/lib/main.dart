import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

String get baseUrl => defaultTargetPlatform == TargetPlatform.android
    ? "http://10.0.2.2/twitterdoparaguai"
    : "http://localhost/twitterdoparaguai";

void main() {
  runApp(const TwitterParaguaiApp());
}

class TwitterParaguaiApp extends StatelessWidget {
  const TwitterParaguaiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Twitter do Paraguai',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const TelaLogin(),
    );
  }
}

// ==========================================
// 1. TELA DE LOGIN
// ==========================================
class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _senhaController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _verificarUsuarioLogado();
  }

  Future<void> _verificarUsuarioLogado() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? emailSalvo = prefs.getString('email');
    String? senhaSalva = prefs.getString('senha');
    int? idSalvo = prefs.getInt('usuario_id');

    if (emailSalvo != null && senhaSalva != null) {
      _emailController.text = emailSalvo;
      _senhaController.text = senhaSalva;

      if (idSalvo != null && idSalvo > 0 && mounted) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => const TelaHome()),
        );
      }
    }
  }

  Future<void> _fazerLogin() async {
    String email = _emailController.text.trim();
    String senha = _senhaController.text;

    if (email.isEmpty || senha.isEmpty) {
      _mostrarMensagem("Preencha todos os campos!");
      return;
    }

    try {
      var url = Uri.parse('$baseUrl/login.php');
      var response = await http.post(
        url,
        body: jsonEncode({"email": email, "senha": senha}),
        headers: {"Content-Type": "application/json"},
      );

      var dados = jsonDecode(response.body);

      if (dados['sucesso'] == true) {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.setInt('usuario_id', dados['id']);
        await prefs.setString('nome', dados['nome']);
        await prefs.setString('email', email);
        await prefs.setString('senha', senha);

        _mostrarMensagem(dados['mensagem']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (context) => const TelaHome()),
          );
        }
      } else {
        _mostrarMensagem(dados['mensagem']);
      }
    } catch (e) {
      _mostrarMensagem("Erro de conexão: $e");
    }
  }

  void _mostrarMensagem(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Login - Twitter do Paraguai')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'E-mail'),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: _senhaController,
              decoration: const InputDecoration(labelText: 'Senha'),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fazerLogin,
              child: const Text('Entrar'),
            ),
            TextButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const TelaCadastro()),
                );
              },
              child: const Text('Não tem conta? Cadastre-se'),
            )
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 2. TELA DE CADASTRO
// ==========================================
class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final TextEditingController _nomeController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _senhaController = TextEditingController();

  Future<void> _fazerCadastro() async {
    String nome = _nomeController.text.trim();
    String email = _emailController.text.trim();
    String senha = _senhaController.text;

    if (nome.isEmpty || email.isEmpty || senha.isEmpty) {
      _mostrarMensagem("Preencha todos os campos!");
      return;
    }

    try {
      var url = Uri.parse('$baseUrl/cadastro.php');
      var response = await http.post(
        url,
        body: jsonEncode({"nome": nome, "email": email, "senha": senha}),
        headers: {"Content-Type": "application/json"},
      );

      var dados = jsonDecode(response.body);

      if (dados['sucesso'] == true) {
        _mostrarMensagem(dados['mensagem']);
        if (mounted) {
          Navigator.pop(context);
        }
      } else {
        _mostrarMensagem(dados['mensagem']);
      }
    } catch (e) {
      _mostrarMensagem("Erro de conexão: $e");
    }
  }

  void _mostrarMensagem(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Cadastro')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: _nomeController,
              decoration: const InputDecoration(labelText: 'Nome'),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'E-mail'),
              keyboardType: TextInputType.emailAddress,
            ),
            TextField(
              controller: _senhaController,
              decoration: const InputDecoration(labelText: 'Senha'),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _fazerCadastro,
              child: const Text('Cadastrar'),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 3. TELA DE NOVA POSTAGEM (TEXTO + FOTO DA CÂMERA OPCIONAL)
// ==========================================
class TelaNovaPostagem extends StatefulWidget {
  const TelaNovaPostagem({super.key});

  @override
  State<TelaNovaPostagem> createState() => _TelaNovaPostagemState();
}

class _TelaNovaPostagemState extends State<TelaNovaPostagem> {
  final TextEditingController _textoController = TextEditingController();
  final ImagePicker _picker = ImagePicker();
  Uint8List? _fotoBytes;
  String? _fotoBase64;

  Future<void> _tirarFotoCamera() async {
    try {
      final XFile? imagemCapturada = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: 800,
        maxHeight: 800,
        imageQuality: 75,
      );

      if (imagemCapturada != null) {
        final bytes = await imagemCapturada.readAsBytes();
        setState(() {
          _fotoBytes = bytes;
          _fotoBase64 = base64Encode(bytes);
        });
      }
    } catch (e) {
      _mostrarMensagem("Erro ao abrir a câmera: $e");
    }
  }

  Future<void> _publicarPostagem() async {
    String texto = _textoController.text.trim();

    if (texto.isEmpty) {
      _mostrarMensagem("Digite o texto da postagem!");
      return;
    }

    SharedPreferences prefs = await SharedPreferences.getInstance();
    int? usuarioId = prefs.getInt('usuario_id');
    String? email = prefs.getString('email');

    if (usuarioId == null && email == null) {
      _mostrarMensagem("Usuário não está logado!");
      return;
    }

    try {
      var url = Uri.parse('$baseUrl/postar.php');
      var response = await http.post(
        url,
        body: jsonEncode({
          "usuario_id": usuarioId,
          "email": email,
          "texto": texto,
          "foto": _fotoBase64 ?? "",
        }),
        headers: {"Content-Type": "application/json"},
      );

      var dados = jsonDecode(response.body);
      _mostrarMensagem(dados['mensagem']);

      if (dados['sucesso'] == true && mounted) {
        Navigator.pop(context, true);
      }
    } catch (e) {
      _mostrarMensagem("Erro ao publicar: $e");
    }
  }

  void _mostrarMensagem(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nova Postagem')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _textoController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'O que está acontecendo?',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _tirarFotoCamera,
              icon: const Icon(Icons.camera_alt),
              label: const Text('Tirar Foto com a Câmera (Opcional)'),
            ),
            if (_fotoBytes != null) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(
                  _fotoBytes!,
                  height: 200,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
              TextButton.icon(
                onPressed: () {
                  setState(() {
                    _fotoBytes = null;
                    _fotoBase64 = null;
                  });
                },
                icon: const Icon(Icons.delete, color: Colors.red),
                label: const Text(
                  'Remover foto',
                  style: TextStyle(color: Colors.red),
                ),
              ),
            ],
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _publicarPostagem,
              icon: const Icon(Icons.send),
              label: const Text('Publicar'),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// 4. TELA PRINCIPAL (FEED, INTERAÇÕES E AMIZADES)
// ==========================================
class TelaHome extends StatefulWidget {
  const TelaHome({super.key});

  @override
  State<TelaHome> createState() => _TelaHomeState();
}

class _TelaHomeState extends State<TelaHome> {
  final TextEditingController _buscaController = TextEditingController();
  String _termoBusca = "";
  int _usuarioId = 0;
  String _nomeUsuario = "";
  String _emailUsuario = "";
  List<dynamic> _usuarios = [];
  List<dynamic> _postagens = [];
  List<dynamic> _solicitacoesPendentes = [];
  bool _carregando = true;

  @override
  void initState() {
    super.initState();
    _carregarDadosIniciais();
  }

  Future<void> _carregarDadosIniciais() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _usuarioId = prefs.getInt('usuario_id') ?? 0;
      _nomeUsuario = prefs.getString('nome') ?? "";
      _emailUsuario = prefs.getString('email') ?? "";
    });
    await _atualizarTudo();
  }

  Future<void> _atualizarTudo() async {
    await Future.wait([
      _carregarPostagens(),
      _carregarSolicitacoesAmizade(),
    ]);
  }

  Future<void> _carregarPostagens() async {
    try {
      String buscaParam = Uri.encodeComponent(_termoBusca.trim());
      var url = Uri.parse(
        '$baseUrl/listar_postagens.php?usuario_id=$_usuarioId&email=$_emailUsuario&busca=$buscaParam',
      );
      var response = await http.get(url);
      var dados = jsonDecode(response.body);

      if (dados['sucesso'] == true) {
        setState(() {
          _usuarios = dados['usuarios'] ?? [];
          _postagens = dados['postagens'] ?? [];
          _carregando = false;
        });
      }
    } catch (e) {
      setState(() {
        _carregando = false;
      });
      _mostrarMensagem("Erro ao carregar feed: $e");
    }
  }

  Future<void> _carregarSolicitacoesAmizade() async {
    if (_usuarioId <= 0) return;
    try {
      var url = Uri.parse(
        '$baseUrl/amizade.php?acao=listar_pendentes&usuario_id=$_usuarioId',
      );
      var response = await http.get(url);
      var dados = jsonDecode(response.body);

      if (dados['sucesso'] == true) {
        setState(() {
          _solicitacoesPendentes = dados['solicitacoes'];
        });
      }
    } catch (_) {}
  }

  Future<void> _curtirPostagem(int postagemId) async {
    try {
      var url = Uri.parse('$baseUrl/curtir.php');
      var response = await http.post(
        url,
        body: jsonEncode({
          "postagem_id": postagemId,
          "usuario_id": _usuarioId,
        }),
        headers: {"Content-Type": "application/json"},
      );
      var dados = jsonDecode(response.body);
      if (dados['sucesso'] == true) {
        _atualizarTudo();
      } else {
        _mostrarMensagem(dados['mensagem']);
      }
    } catch (e) {
      _mostrarMensagem("Erro ao curtir: $e");
    }
  }

  Future<void> _solicitarAmizade(int destinatarioId) async {
    try {
      var url = Uri.parse('$baseUrl/amizade.php');
      var response = await http.post(
        url,
        body: jsonEncode({
          "acao": "solicitar",
          "solicitante_id": _usuarioId,
          "destinatario_id": destinatarioId,
        }),
        headers: {"Content-Type": "application/json"},
      );
      var dados = jsonDecode(response.body);
      _mostrarMensagem(dados['mensagem']);
      _atualizarTudo();
    } catch (e) {
      _mostrarMensagem("Erro ao solicitar amizade: $e");
    }
  }

  Future<void> _aceitarAmizade(int amizadeId) async {
    try {
      var url = Uri.parse('$baseUrl/amizade.php');
      var response = await http.post(
        url,
        body: jsonEncode({
          "acao": "aceitar",
          "amizade_id": amizadeId,
        }),
        headers: {"Content-Type": "application/json"},
      );
      var dados = jsonDecode(response.body);
      _mostrarMensagem(dados['mensagem']);
      _atualizarTudo();
    } catch (e) {
      _mostrarMensagem("Erro ao aceitar amizade: $e");
    }
  }

  Future<void> _enviarComentario(int postagemId, String texto) async {
    if (texto.trim().isEmpty) {
      _mostrarMensagem("Digite um comentário!");
      return;
    }

    try {
      var url = Uri.parse('$baseUrl/comentar.php');
      var response = await http.post(
        url,
        body: jsonEncode({
          "postagem_id": postagemId,
          "usuario_id": _usuarioId,
          "texto": texto.trim(),
        }),
        headers: {"Content-Type": "application/json"},
      );
      var dados = jsonDecode(response.body);
      _mostrarMensagem(dados['mensagem']);
      if (dados['sucesso'] == true) {
        _atualizarTudo();
      }
    } catch (e) {
      _mostrarMensagem("Erro ao comentar: $e");
    }
  }

  void _abrirDialogoComentario(int postagemId) {
    final TextEditingController comentarioController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Novo Comentário'),
          content: TextField(
            controller: comentarioController,
            decoration: const InputDecoration(
              hintText: 'Digite seu comentário...',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _enviarComentario(postagemId, comentarioController.text);
              },
              child: const Text('Comentar'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const TelaLogin()),
      );
    }
  }

  void _mostrarMensagem(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  Widget _construirFotoPostagem(String fotoStr) {
    try {
      if (fotoStr.startsWith('http://') || fotoStr.startsWith('https://')) {
        return Image.network(
          fotoStr,
          height: 200,
          width: double.infinity,
          fit: BoxFit.cover,
        );
      } else {
        Uint8List bytes = base64Decode(fotoStr);
        return Image.memory(
          bytes,
          height: 200,
          width: double.infinity,
          fit: BoxFit.cover,
        );
      }
    } catch (_) {
      return const SizedBox.shrink();
    }
  }

  Widget _construirBotaoAmizade(Map<String, dynamic> post) {
    String status = post['status_amizade'] ?? 'nenhuma';
    int autorId = post['usuario_id'];
    int amizadeId = post['amizade_id'] ?? 0;

    if (status == 'proprio') {
      return const Text(
        '(Você)',
        style: TextStyle(color: Colors.grey, fontSize: 12),
      );
    } else if (status == 'aceita') {
      return const Chip(
        label: Text('Amigos', style: TextStyle(fontSize: 12)),
        backgroundColor: Colors.greenAccent,
      );
    } else if (status == 'pendente_enviada') {
      return const Text(
        'Solicitação enviada',
        style: TextStyle(color: Colors.orange, fontSize: 12),
      );
    } else if (status == 'pendente_recebida') {
      return ElevatedButton(
        onPressed: () => _aceitarAmizade(amizadeId),
        child: const Text('Aprovar Amizade'),
      );
    } else {
      return TextButton.icon(
        onPressed: () => _solicitarAmizade(autorId),
        icon: const Icon(Icons.person_add, size: 18),
        label: const Text('Solicitar Amizade'),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    String termo = _termoBusca.toLowerCase().trim();

    List<dynamic> usuariosExibidos = termo.isEmpty
        ? []
        : _usuarios.where((u) {
            String nome = (u['nome'] ?? '').toString().toLowerCase();
            return nome.contains(termo);
          }).toList();

    List<dynamic> postagensExibidas = _postagens.where((post) {
      if (termo.isEmpty) return true;
      String nomeAutor = (post['autor_nome'] ?? '').toString().toLowerCase();
      String tituloPost = (post['texto'] ?? '').toString().toLowerCase();
      return nomeAutor.contains(termo) || tituloPost.contains(termo);
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          _nomeUsuario.isNotEmpty ? 'Feed ($_nomeUsuario)' : 'Feed',
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Atualizar',
            onPressed: _atualizarTudo,
          ),
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'Sair',
            onPressed: () => _logout(context),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          var criou = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const TelaNovaPostagem()),
          );
          if (criou == true) {
            _atualizarTudo();
          }
        },
        child: const Icon(Icons.add),
      ),
      body: _carregando
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    controller: _buscaController,
                    onChanged: (valor) {
                      setState(() {
                        _termoBusca = valor;
                      });
                    },
                    onSubmitted: (_) => _carregarPostagens(),
                    decoration: InputDecoration(
                      labelText: 'Buscar por usuário ou título do post',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _termoBusca.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear),
                              onPressed: () {
                                _buscaController.clear();
                                setState(() {
                                  _termoBusca = "";
                                });
                                _carregarPostagens();
                              },
                            )
                          : null,
                      border: const OutlineInputBorder(),
                    ),
                  ),
                ),
                if (usuariosExibidos.isNotEmpty)
                  Container(
                    width: double.infinity,
                    margin: const EdgeInsets.symmetric(horizontal: 12.0),
                    padding: const EdgeInsets.all(8.0),
                    decoration: BoxDecoration(
                      color: Colors.blue.shade50,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Usuários encontrados:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        ...usuariosExibidos.map((u) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.person, size: 18),
                                  const SizedBox(width: 6),
                                  Text(
                                    u['nome'] ?? 'Usuário',
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                              _construirBotaoAmizade(u),
                            ],
                          );
                        }),
                      ],
                    ),
                  ),
                if (_solicitacoesPendentes.isNotEmpty)
                  Container(
                    width: double.infinity,
                    color: Colors.amber.shade100,
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Solicitações de Amizade Pendentes:',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        ..._solicitacoesPendentes.map((sol) {
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('${sol['solicitante_nome']} quer ser seu amigo'),
                              ElevatedButton(
                                onPressed: () =>
                                    _aceitarAmizade(sol['amizade_id']),
                                child: const Text('Aprovar'),
                              ),
                            ],
                          );
                        }),
                      ],
                    ),
                  ),
                Expanded(
                  child: postagensExibidas.isEmpty
                      ? const Center(
                          child: Text('Nenhuma postagem encontrada.'),
                        )
                      : ListView.builder(
                          itemCount: postagensExibidas.length,
                          itemBuilder: (context, index) {
                            var post = postagensExibidas[index];
                            bool curtiu = post['curtiu'] == true;
                            String statusAmizade =
                                post['status_amizade'] ?? 'nenhuma';
                            List<dynamic> comentarios =
                                post['comentarios'] ?? [];
                            String? foto = post['foto'];

                            return Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 6,
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          post['autor_nome'] ?? 'Usuário',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                        _construirBotaoAmizade(post),
                                      ],
                                    ),
                                    const SizedBox(height: 8),
                                    Text(
                                      post['texto'] ?? '',
                                      style: const TextStyle(fontSize: 15),
                                    ),
                                    if (foto != null &&
                                        foto.toString().trim().isNotEmpty) ...[
                                      const SizedBox(height: 8),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(8),
                                        child: _construirFotoPostagem(
                                          foto.toString().trim(),
                                        ),
                                      ),
                                    ],
                                    const Divider(),
                                    Row(
                                      children: [
                                        IconButton(
                                          icon: Icon(
                                            curtiu
                                                ? Icons.favorite
                                                : Icons.favorite_border,
                                            color: curtiu
                                                ? Colors.red
                                                : Colors.grey,
                                          ),
                                          onPressed: () =>
                                              _curtirPostagem(post['id']),
                                        ),
                                        Text('${post['curtidas']} curtidas'),
                                        const SizedBox(width: 16),
                                        if (statusAmizade == 'aceita')
                                          TextButton.icon(
                                            onPressed: () =>
                                                _abrirDialogoComentario(
                                                    post['id']),
                                            icon: const Icon(
                                              Icons.comment,
                                              size: 18,
                                            ),
                                            label: const Text('Comentar'),
                                          )
                                        else
                                          const Expanded(
                                            child: Text(
                                              'Só amigos podem comentar',
                                              style: TextStyle(
                                                color: Colors.grey,
                                                fontSize: 12,
                                                fontStyle: FontStyle.italic,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                    if (comentarios.isNotEmpty) ...[
                                      const Divider(),
                                      const Text(
                                        'Comentários:',
                                        style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      ...comentarios.map((com) {
                                        return Padding(
                                          padding: const EdgeInsets.symmetric(
                                            vertical: 2.0,
                                          ),
                                          child: Text(
                                            '${com['autor_nome']}: ${com['texto']}',
                                            style:
                                                const TextStyle(fontSize: 13),
                                          ),
                                        );
                                      }),
                                    ],
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
