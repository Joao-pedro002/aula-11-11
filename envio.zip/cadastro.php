<?php
include 'conexao.php';

$dados = json_decode(file_get_contents("php://input"));

if (isset($dados->nome) && isset($dados->email) && isset($dados->senha)) {
    $nome = $conn->real_escape_string(trim($dados->nome));
    $email = $conn->real_escape_string(trim($dados->email));
    $senhaHash = password_hash($dados->senha, PASSWORD_DEFAULT);

    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senhaHash')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode([
            "sucesso" => true,
            "mensagem" => "Cadastro realizado com sucesso!"
        ]);
    } else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "Erro ao cadastrar: E-mail já existe ou falha no banco."
        ]);
    }
} else {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Dados incompletos."
    ]);
}

$conn->close();
?>