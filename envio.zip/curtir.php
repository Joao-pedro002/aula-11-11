<?php
include 'conexao.php';

$dados = json_decode(file_get_contents("php://input"));

if (isset($dados->postagem_id) && isset($dados->usuario_id)) {
    $postagem_id = (int)$dados->postagem_id;
    $usuario_id = (int)$dados->usuario_id;

    // Verifica se já curtiu
    $check = $conn->query("SELECT id FROM curtidas WHERE postagem_id = $postagem_id AND usuario_id = $usuario_id LIMIT 1");

    if ($check && $check->num_rows > 0) {
        // Se já curtiu, remove a curtida (descurtir)
        $conn->query("DELETE FROM curtidas WHERE postagem_id = $postagem_id AND usuario_id = $usuario_id");
        echo json_encode(["sucesso" => true, "mensagem" => "Curtida removida!"]);
    } else {
        // Se não curtiu, adiciona a curtida
        if ($conn->query("INSERT INTO curtidas (postagem_id, usuario_id) VALUES ($postagem_id, $usuario_id)") === TRUE) {
            echo json_encode(["sucesso" => true, "mensagem" => "Postagem curtida!"]);
        } else {
            echo json_encode(["sucesso" => false, "mensagem" => "Erro ao curtir postagem."]);
        }
    }
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Dados incompletos."]);
}

$conn->close();
?>