<?php
include 'conexao.php';

$usuario_id = isset($_GET['usuario_id']) ? (int)$_GET['usuario_id'] : 0;

if ($usuario_id <= 0 && isset($_GET['email'])) {
    $email = $conn->real_escape_string(trim($_GET['email']));
    $resUser = $conn->query("SELECT id FROM usuarios WHERE email = '$email' LIMIT 1");
    if ($resUser && $resUser->num_rows > 0) {
        $rowUser = $resUser->fetch_assoc();
        $usuario_id = (int)$rowUser['id'];
    }
}

$busca = isset($_GET['busca']) ? $conn->real_escape_string(trim($_GET['busca'])) : '';

// Função auxiliar para checar status de amizade entre $usuario_id e $outro_id
function obterStatusAmizade($conn, $usuario_id, $outro_id) {
    $statusAmizade = "nenhuma";
    $amizadeId = 0;

    if ($usuario_id == $outro_id) {
        $statusAmizade = "proprio";
    } elseif ($usuario_id > 0) {
        $sqlAmizade = "SELECT id, solicitante_id, destinatario_id, status FROM amizades
                       WHERE (solicitante_id = $usuario_id AND destinatario_id = $outro_id)
                          OR (solicitante_id = $outro_id AND destinatario_id = $usuario_id)
                       LIMIT 1";
        $resAmizade = $conn->query($sqlAmizade);
        if ($resAmizade && $resAmizade->num_rows > 0) {
            $amz = $resAmizade->fetch_assoc();
            $amizadeId = (int)$amz['id'];
            if ($amz['status'] === 'aceita') {
                $statusAmizade = "aceita";
            } elseif ((int)$amz['solicitante_id'] === $usuario_id) {
                $statusAmizade = "pendente_enviada";
            } else {
                $statusAmizade = "pendente_recebida";
            }
        }
    }

    return ["status" => $statusAmizade, "amizade_id" => $amizadeId];
}

// 1. Lista de usuários cadastrados (filtrada por nome se houver busca)
$filtroUsuarios = "";
if ($busca !== '') {
    $filtroUsuarios = " WHERE nome LIKE '%$busca%' ";
}
$sqlUsuarios = "SELECT id, nome, email FROM usuarios $filtroUsuarios ORDER BY nome ASC";
$resUsuarios = $conn->query($sqlUsuarios);
$usuarios = [];

if ($resUsuarios) {
    while ($uRow = $resUsuarios->fetch_assoc()) {
        $uId = (int)$uRow['id'];
        $dadosAmz = obterStatusAmizade($conn, $usuario_id, $uId);
        $usuarios[] = [
            "usuario_id" => $uId,
            "nome" => $uRow['nome'],
            "email" => $uRow['email'],
            "status_amizade" => $dadosAmz['status'],
            "amizade_id" => $dadosAmz['amizade_id']
        ];
    }
}

// 2. Lista de postagens (filtrada por autor ou texto se houver busca)
$filtroSql = "";
if ($busca !== '') {
    $filtroSql = " WHERE u.nome LIKE '%$busca%' OR p.texto LIKE '%$busca%' ";
}

$sql = "SELECT p.id, p.usuario_id, p.texto, p.foto, p.criado_em, u.nome AS autor_nome, u.email AS autor_email
        FROM postagens p
        INNER JOIN usuarios u ON p.usuario_id = u.id
        $filtroSql
        ORDER BY p.id DESC";

$resultado = $conn->query($sql);
$postagens = [];

if ($resultado) {
    while ($row = $resultado->fetch_assoc()) {
        $postagem_id = (int)$row['id'];
        $autor_id = (int)$row['usuario_id'];

        // Total de curtidas
        $resCurtidas = $conn->query("SELECT COUNT(*) AS total FROM curtidas WHERE postagem_id = $postagem_id");
        $totalCurtidas = 0;
        if ($resCurtidas && $rC = $resCurtidas->fetch_assoc()) {
            $totalCurtidas = (int)$rC['total'];
        }

        // Verifica se o usuário atual curtiu
        $curtiu = false;
        if ($usuario_id > 0) {
            $resCurtiu = $conn->query("SELECT id FROM curtidas WHERE postagem_id = $postagem_id AND usuario_id = $usuario_id LIMIT 1");
            if ($resCurtiu && $resCurtiu->num_rows > 0) {
                $curtiu = true;
            }
        }

        // Verifica status de amizade entre usuario_id e autor_id
        $dadosAmzPost = obterStatusAmizade($conn, $usuario_id, $autor_id);

        // Lista comentários da postagem
        $comentarios = [];
        $sqlCom = "SELECT c.id, c.texto, c.criado_em, u.nome AS autor_nome
                   FROM comentarios c
                   INNER JOIN usuarios u ON c.usuario_id = u.id
                   WHERE c.postagem_id = $postagem_id
                   ORDER BY c.id ASC";
        $resCom = $conn->query($sqlCom);
        if ($resCom) {
            while ($cRow = $resCom->fetch_assoc()) {
                $comentarios[] = [
                    "id" => (int)$cRow['id'],
                    "autor_nome" => $cRow['autor_nome'],
                    "texto" => $cRow['texto'],
                    "criado_em" => $cRow['criado_em']
                ];
            }
        }

        $postagens[] = [
            "id" => $postagem_id,
            "usuario_id" => $autor_id,
            "autor_nome" => $row['autor_nome'],
            "texto" => $row['texto'],
            "foto" => $row['foto'],
            "criado_em" => $row['criado_em'],
            "curtidas" => $totalCurtidas,
            "curtiu" => $curtiu,
            "status_amizade" => $dadosAmzPost['status'],
            "amizade_id" => $dadosAmzPost['amizade_id'],
            "comentarios" => $comentarios
        ];
    }
}

echo json_encode([
    "sucesso" => true,
    "usuarios" => $usuarios,
    "postagens" => $postagens
]);

$conn->close();
?>