<?php
include 'conexao.php';

$dados = json_decode(file_get_contents("php://input"));

if (isset($dados->texto) && (isset($dados->usuario_id) || isset($dados->email))) {
    $usuario_id = 0;

    if (isset($dados->usuario_id) && (int)$dados->usuario_id > 0) {
        $usuario_id = (int)$dados->usuario_id;
    } elseif (isset($dados->email)) {
        $email = $conn->real_escape_string(trim($dados->email));
        $resUser = $conn->query("SELECT id FROM usuarios WHERE email = '$email' LIMIT 1");
        if ($resUser && $resUser->num_rows > 0) {
            $rowUser = $resUser->fetch_assoc();
            $usuario_id = (int)$rowUser['id'];
        }
    }

    if ($usuario_id <= 0) {
        echo json_encode(["sucesso" => false, "mensagem" => "Usuário inválido!"]);
        $conn->close();
        exit();
    }

    $texto = $conn->real_escape_string(trim($dados->texto));
    $foto = isset($dados->foto) && trim($dados->foto) !== "" ? "'" . $conn->real_escape_string(trim($dados->foto)) . "'" : "NULL";

    $sql = "INSERT INTO postagens (usuario_id, texto, foto) VALUES ($usuario_id, '$texto', $foto)";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(["sucesso" => true, "mensagem" => "Postagem publicada com sucesso!"]);
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Erro ao salvar postagem."]);
    }
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Preencha o texto da postagem."]);
}

$conn->close();
?>