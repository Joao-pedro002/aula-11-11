<?php
include 'conexao.php';

$dados = json_decode(file_get_contents("php://input"));

if (isset($dados->email) && isset($dados->senha)) {
    $email = $conn->real_escape_string(trim($dados->email));
    $senha = $dados->senha;

    $sql = "SELECT id, nome, email, senha FROM usuarios WHERE email = '$email' LIMIT 1";
    $resultado = $conn->query($sql);

    if ($resultado && $resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();

        if (password_verify($senha, $usuario['senha']) || $senha === $usuario['senha']) {
            echo json_encode([
                "sucesso" => true,
                "mensagem" => "Login realizado com sucesso!",
                "id" => (int)$usuario['id'],
                "nome" => $usuario['nome'],
                "email" => $usuario['email']
            ]);
        } else {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Senha incorreta!"
            ]);
        }
    } else {
        echo json_encode([
            "sucesso" => false,
            "mensagem" => "E-mail não encontrado!"
        ]);
    }
} else {
    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Dados incompletos."
    ]);
}

$conn->close();
?>