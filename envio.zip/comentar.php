<?php
include 'conexao.php';

$dados = json_decode(file_get_contents("php://input"));

if (isset($dados->postagem_id) && isset($dados->usuario_id) && isset($dados->texto)) {
    $postagem_id = (int)$dados->postagem_id;
    $usuario_id = (int)$dados->usuario_id;
    $texto = $conn->real_escape_string(trim($dados->texto));

    if ($texto === "") {
        echo json_encode(["sucesso" => false, "mensagem" => "Digite um comentário!"]);
        $conn->close();
        exit();
    }

    // Descobre quem é o autor da postagem
    $resPost = $conn->query("SELECT usuario_id FROM postagens WHERE id = $postagem_id LIMIT 1");
    if (!$resPost || $resPost->num_rows == 0) {
        echo json_encode(["sucesso" => false, "mensagem" => "Postagem não encontrada."]);
        $conn->close();
        exit();
    }

    $post = $resPost->fetch_assoc();
    $autor_id = (int)$post['usuario_id'];

    // Verifica se o usuário é amigo do autor da postagem (status = 'aceita')
    $sqlAmizade = "SELECT id FROM amizades
                   WHERE ((solicitante_id = $usuario_id AND destinatario_id = $autor_id)
                      OR (solicitante_id = $autor_id AND destinatario_id = $usuario_id))
                     AND status = 'aceita'
                   LIMIT 1";
    $resAmizade = $conn->query($sqlAmizade);

    if ($resAmizade && $resAmizade->num_rows > 0) {
        $sqlInsert = "INSERT INTO comentarios (postagem_id, usuario_id, texto) VALUES ($postagem_id, $usuario_id, '$texto')";
        if ($conn->query($sqlInsert) === TRUE) {
            echo json_encode(["sucesso" => true, "mensagem" => "Comentário enviado!"]);
        } else {
            echo json_encode(["sucesso" => false, "mensagem" => "Erro ao salvar comentário."]);
        }
    } else {
        echo json_encode(["sucesso" => false, "mensagem" => "Você só pode comentar em postagens de amigos!"]);
    }
} else {
    echo json_encode(["sucesso" => false, "mensagem" => "Dados incompletos."]);
}

$conn->close();
?>